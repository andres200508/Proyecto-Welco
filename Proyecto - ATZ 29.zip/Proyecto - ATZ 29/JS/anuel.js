window.addEventListener("load", function(){
    console.log("tuki");

    var imagenes = [];
    imagenes[0] = "../IMG/anuel-1-e1670782616531-1000x600.jpg";
    imagenes[1] = "../IMG/images (1).jpeg";
    imagenes[2] = "../IMG/images.jpeg";

    var indiceImagenes = 0;
    var tiempo = 1000;
    function cambiarImagenes(){
        document.getElementsByName("carrusel")[0].src = imagenes [indiceImagenes];

        if (indiceImagenes < 2) {
            indiceImagenes++;
        } else {
            indiceImagenes = 0;
        }
    }
this.setInterval(cambiarImagenes, tiempo);
});
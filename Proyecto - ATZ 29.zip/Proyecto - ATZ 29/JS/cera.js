window.addEventListener("load", function(){
    console.log("tuki");

    var imagenes = [];
    imagenes[0] ="../IMG/cera1.jpg";
    imagenes[1] ="../IMG/cera2.jpg";
    imagenes[2] ="../IMG/cera3.jpg";
    imagenes[3] ="../IMG/cera4.jpg";

    var indiceImagenes = 0;
    var tiempo = 1000;
    function cambiarImagenes(){
        document.getElementsByName("carrusel")[0].src = imagenes [indiceImagenes];

        if (indiceImagenes < 3) {
            indiceImagenes++;
        } else {
            indiceImagenes = 0;
        }
    }
this.setInterval(cambiarImagenes, tiempo);
});
